function CTableController(){
    var _aEnlights;
    var _oContainer;
    
    var _aCbCompleted;
    var _aCbOwner;
    
    var _aDoubleDigitText;
    
    //var aEnlightBetAmountText; 
    //var aWinBoxWinAmountText;
    //var aWinBoxBetAmountText;
    
    var aEnlightSelectedNumText;
    var aWinBoxSelectedNumText;
    


    this._init = function(){
        _oContainer = new createjs.Container();
        _oContainer.x = 40;
        _oContainer.y = 80;
        s_oStage.addChild(_oContainer);
        
   
        
        var oBg = createBitmap(s_oSpriteLibrary.getSprite('board_roulette'));
        _oContainer.addChild(oBg);
        
        //Preet Logic: double didgit number texts
        _aDoubleDigitText=new Array();
        for(var i = 0; i < 10; i++) {
            _aDoubleDigitText[i]=new Array();
        }
 
		var baseX = 96;
		var baseY = 67;
		
        for(var i = 0; i < 10; i++) {
        
        	for(var j = 0; j < 10; j++) {
        		_aDoubleDigitText[i][j]=new createjs.Text(i + "" + j,"16px "+FONT1, "#000");
        		_aDoubleDigitText[i][j].x = baseX + (j * 60);
        		_aDoubleDigitText[i][j].y = baseY + (i * 29.5);
        		_aDoubleDigitText[i][j].textAlign = "center";
        		_oContainer.addChild(_aDoubleDigitText[i][j]);
        	}
        }
        
      //INIT ALL BUTTONS
        var oBut;

        
        //Preet Logic: For Random Bets (5/10/15/20/25/50/75)
        var iCurX = 45;
        var iCurY = 410;
        for(var i=1;i<8;i++){
        	var tmp = 5;
        	if(i === 6) {
        		tmp = 50;
        	} else if(i === 7) {
        		tmp = 75;
        	} else {
        		tmp = i * 5;
        	}
	        oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite("number_random_" + tmp),"rand" + tmp,_oContainer,true);
	        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
	        if(s_bMobile === false){
	            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
	            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
	        }
	        
	        iCurX += 35;
        }
        
        
        this._initEnlights();
        
        /*******************TWELVE BET***************/
        /*
        oBut = new CBetTableButton(221,289,s_oSpriteLibrary.getSprite('hit_area_horizontal'),"first12",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(470,289,s_oSpriteLibrary.getSprite('hit_area_horizontal'),"second12",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(717,289,s_oSpriteLibrary.getSprite('hit_area_horizontal'),"third12",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        */
        /*************************SIMPLE BETS******************/
        /*
        oBut = new CBetTableButton(54,121,s_oSpriteLibrary.getSprite('hit_area_0'),"bet_0",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
		*/
        
        
        //Preet Logic: each double digit numbers clicks
        var oSprite = s_oSpriteLibrary.getSprite('hit_area_number');

        var iCurX = 97;
        var iCurY = 46;
        for(var i=0;i<100;i++){
            if(i%10 === 0){
            	iCurX = 97;
            	iCurY += HEIGHT_CELL_NUMBER + 0.5;
            }else{
            	iCurX += WIDTH_CELL_NUMBER + 0.5; 
            }
        	
        	oBut = new CBetTableButton(iCurX,iCurY,oSprite,"bet_"+i,_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
        }
        
        //Preet Logic: bahar number
        var oSprite = s_oSpriteLibrary.getSprite('hit_area_baharandar');

        var iCurX = 94;
        var iCurY = 460;
        for(var i=0;i<10;i++){            
        	oBut = new CBetTableButton(iCurX,iCurY,oSprite,"bet_10"+i,_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            iCurX += WIDTH_CELL_NUMBER + 2.5;
            
            
        }
        
        //Preet Logic: andar number
        var oSprite = s_oSpriteLibrary.getSprite('hit_area_baharandar');

        var iCurX = 94;
        var iCurY = 525;
        for(var i=0;i<10;i++){            
        	oBut = new CBetTableButton(iCurX,iCurY,oSprite,"bet_11"+i,_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            iCurX += WIDTH_CELL_NUMBER + 2.5;
            
            
        }
        
        
        //Preet Logic: For "ALL" Rows & cols
        var iCurX = 47;
        var iCurY = 75;
        for(var i=0;i<10;i++){
	        oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite('hit_area_all_row'),"row" + i,_oContainer,true);
	        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
	        if(s_bMobile === false){
	            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
	            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
	        }
	        
	        iCurY += 30;
        }
        
        
        //Preet Logic: For "ALL" Rows & cols
        var iCurX = 100;
        var iCurY = 370;
        for(var i=0;i<10;i++){
	        oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite('hit_area_all_col'),"col" + i,_oContainer,true);
	        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
	        if(s_bMobile === false){
	            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
	            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
	        }
	        
	        iCurX += 60;
        }
        
        

        
		
        /**********************COUPLE BET***********************/
        /*
        oBut = new CBetTableButton(97,195,s_oSpriteLibrary.getSprite('hit_area_couple_vertical'),"bet_0_1",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(97,120,s_oSpriteLibrary.getSprite('hit_area_couple_vertical'),"bet_0_2",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }

        oBut = new CBetTableButton(97,45,s_oSpriteLibrary.getSprite('hit_area_couple_vertical'),"bet_0_3",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        var iCurX = 159;
        var iCurY = 194;
        for(var j=1;j<34;j++){
            oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite('hit_area_couple_vertical'),"bet_"+j+"_"+(j+3),_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            if(j%3 === 0){
                iCurX += WIDTH_CELL_NUMBER + 3; 
                iCurY = 194;
            }else{
                iCurY -= HEIGHT_CELL_NUMBER + 3;
            }
        }
        */
        
        
	/********************COUPLE BET HORIZONTAL***********************/
        /*
        var iCurX = 128;
        var iCurY = 157;
        var iCont = 1;
        for(var j=1;j<25;j++){
            oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite('hit_area_couple_horizontal'),"bet_"+iCont+"_"+(iCont+1),_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            if(j%2 === 0){
                iCurX += WIDTH_CELL_NUMBER + 3; 
                iCurY = 157;
                iCont += 2;
            }else{
                iCurY -= HEIGHT_CELL_NUMBER + 3;
                iCont++;
            }
        }
        */
	
        /*********************TRIPLE BET*******************/
        /*
        oBut = new CBetTableButton(96,158,s_oSpriteLibrary.getSprite('hit_area_small'),"bet_0_1_2",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(96,84,s_oSpriteLibrary.getSprite('hit_area_small'),"bet_0_2_3",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        var iCurX = 128;
        var iCurY = 232;
        var iCont = 1;
        var oSprite = s_oSpriteLibrary.getSprite('hit_area_couple_horizontal');
        for(var j=1;j<13;j++){
            oBut = new CBetTableButton(iCurX,iCurY,oSprite,"bet_"+iCont+"_"+(iCont+1)+"_"+(iCont+2),_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            iCurX += WIDTH_CELL_NUMBER + 3;
            iCont += 3;
        }
		*/
        /******************QUADRUPLE BET******************/
        /*
        
        oBut = new CBetTableButton(96,232,s_oSpriteLibrary.getSprite('hit_area_small'),"bet_0_1_2_3",_oContainer,false);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        var iCurX = 158;
        var iCurY = 158;
        var iCont = 1;
        for(var k=1;k<23;k++){
            oBut = new CBetTableButton(iCurX,iCurY,s_oSpriteLibrary.getSprite('hit_area_small'),"bet_"+iCont+"_"+(iCont+1)+"_"+(iCont+3)+"_"+(iCont+4),_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            if(k%2 === 0){
                iCurX += WIDTH_CELL_NUMBER + 3; 
                iCurY = 157;
                iCont += 2;
            }else{
                iCurY -= HEIGHT_CELL_NUMBER + 3;
                iCont++;
            }
        }
        */
        /****************SESTUPLE BET**********************/
        /*
        var iCurX = 158;
        var iCurY = 232;
        var iCont = 1;
        var oSprite = s_oSpriteLibrary.getSprite('hit_area_small');
        for(var k=1;k<12;k++){
            oBut = new CBetTableButton(iCurX,iCurY,oSprite,"bet_"+iCont+"_"+(iCont+1)+"_"+(iCont+2)+"_"+(iCont+3)+"_"+(iCont+4)+"_"+(iCont+5),_oContainer,false);
            oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
            if(s_bMobile === false){
                oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
                oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
            }
            
            iCont += 3;
            iCurX += WIDTH_CELL_NUMBER + 3;
        }
        */
       
        /****************COL BET*****************/
        /*
        oBut = new CBetTableButton(872,194,s_oSpriteLibrary.getSprite('hit_area_number'),"col1",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(872,120,s_oSpriteLibrary.getSprite('hit_area_number'),"col2",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(872,46,s_oSpriteLibrary.getSprite('hit_area_number'),"col3",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        */
        /****************OTHER BETS******************/
        /*
        oBut = new CBetTableButton(159,400,s_oSpriteLibrary.getSprite('hit_area_horizontal_half'),"first18",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(281,400,s_oSpriteLibrary.getSprite('hit_area_horizontal_half'),"even",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(408,400,s_oSpriteLibrary.getSprite('hit_area_color'),"black",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(533,400,s_oSpriteLibrary.getSprite('hit_area_color'),"red",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(656,400,s_oSpriteLibrary.getSprite('hit_area_horizontal_half'),"odd",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        
        oBut = new CBetTableButton(778,400,s_oSpriteLibrary.getSprite('hit_area_horizontal_half'),"second18",_oContainer,true);
        oBut.addEventListener(ON_MOUSE_DOWN, this._onBetPress, this);
        if(s_bMobile === false){
            oBut.addEventListener(ON_MOUSE_OVER, this._onBetNumberOver, this);
            oBut.addEventListener(ON_MOUSE_OUT,this._onBetNumberOut,this);
        }
        */
        
        
        _aCbCompleted=new Array();
        _aCbOwner =new Array();
    };
    
    this._initEnlights = function(){
        var oBmp;
        _aEnlights = new Array();
        
        /*********************NUMBER ENLIGHT*****************/
        /*
        oBmp = new CEnlight(11,10,s_oSpriteLibrary.getSprite('enlight_0'),_oContainer);
        _aEnlights["oEnlight_0"] = oBmp;
        */
        
        //Preet logic: added for odd/even number values betting enlight sprite
        //Preet Logic: added to show the number on which mouse is over and the betting amout
        
        var iCurX = 70;
        var iCurY = 33;
        var oSprite_even = s_oSpriteLibrary.getSprite('enlight_number_even'); 
        var oSprite_odd = s_oSpriteLibrary.getSprite('enlight_number_odd');
       
        aEnlightSelectedNumText = new Array();
        aEnlightBetAmountText = new Array();
        
        aWinBoxSelectedNumText = new Array();
        aWinBoxBetAmountText = new Array();
        aWinBoxWinAmountText = new Array();
        
        var iWinX;
        var iWinY;
        var oWinBox;
        var oSprite_win = s_oSpriteLibrary.getSprite('enlight_number_win'); 
        var oSprite_ab = s_oSpriteLibrary.getSprite('enlight_baharandar');
        
        //Preet Logic: Bahar enlight
        var iCurbX = 60; // Uncomment: Original code: 98
        var iCurbY = 427; // Uncomment: Original code: 159
        
        
        for(var i=0;i<120;i++){
        	offsetX = 0;
        	offsetY = 0;
        	if(i < 100) {
        		if(i%10 === 0){
                	iCurX = 70;
                	iCurY += oSprite_even.height + 0.5;
                	iWinX = iCurX + 10;	
                	iWinY = iCurY - 70;	
                }else{
                	iCurX += oSprite_even.width + 0.5;
                	iWinX = iCurX + 10;	
                }
            	
            	if(i%2 === 0) {
            		oBmp = new CEnlight(iCurX,iCurY,oSprite_even,_oContainer); //Enlight image for even numbers
            	} else {
            		oBmp = new CEnlight(iCurX,iCurY,oSprite_odd,_oContainer);	//Enlight image for odd numbers
            	}
            	
        		//Preet: DoubleDigit number text over Enlight image
                aEnlightSelectedNumText[i]=new createjs.Text("??","12px "+FONT1, "#fff");
                aEnlightSelectedNumText[i].x = iCurX + 27;
                aEnlightSelectedNumText[i].y = iCurY;
                aEnlightSelectedNumText[i].textAlign = "center";
        		_oContainer.addChild(aEnlightSelectedNumText[i]);
        		aEnlightSelectedNumText[i].visible = false;
        	} else if(i < 110) {
        		iCurX = 60;
        		iCurY = 427;
        		iCurX = iCurX + ((i -100) * 61.5);
        		iWinX = iCurX + 10;	
            	iWinY = iCurY - 70;
            	offsetX = 6;
            	offsetY = 27;
        		oBmp = new CEnlight(iCurX,iCurY,oSprite_ab,_oContainer);
        	} else if(i < 120) {
        		iCurX = 60;
        		iCurY = 490;
        		iCurX = iCurX + ((i -110) * 61.5); 
        		iWinX = iCurX + 10;	
            	iWinY = iCurY - 70;
            	offsetX = 6;
            	offsetY = 27;
        		oBmp = new CEnlight(iCurX,iCurY,oSprite_ab,_oContainer);
        	}
        	
        	
        	//Preet: Bet amount text over Enlight image
        	aEnlightBetAmountText[i]=new createjs.Text("??","12px "+FONT2, "#000");
        	aEnlightBetAmountText[i].textAlign = "center";
        	aEnlightBetAmountText[i].x = iCurX + 27 + offsetX;
    		aEnlightBetAmountText[i].y = iCurY + 15 + offsetY;
    		_oContainer.addChild(aEnlightBetAmountText[i]);
    		aEnlightBetAmountText[i].visible = false;
            
    		//Preet: Detailed win box image over Enlight image
        	oWinBox = new CEnlight(iWinX,iWinY,oSprite_win,_oContainer); //Preet Logic: added to show the number on which mouse is over and the betting amout
        	oWinBox.visible = false;
        	
        	
        	aWinBoxSelectedNumText[i]=new createjs.Text("??","10px "+FONT1, "#fff");
        	aWinBoxSelectedNumText[i].textAlign = "center";
        	aWinBoxSelectedNumText[i].x = iWinX + 30;
        	aWinBoxSelectedNumText[i].y = iWinY + 7;
    		_oContainer.addChild(aWinBoxSelectedNumText[i]);
    		aWinBoxSelectedNumText[i].visible = false;
        	
    		aWinBoxBetAmountText[i]=new createjs.Text("??","10px "+FONT1, "#fff");
    		aWinBoxBetAmountText[i].x = iWinX + 30;
    		aWinBoxBetAmountText[i].y = iWinY + 20;
    		aWinBoxBetAmountText[i].textAlign = "center";
    		_oContainer.addChild(aWinBoxBetAmountText[i]);
    		aWinBoxBetAmountText[i].visible = false;
    		
    		
    		aWinBoxWinAmountText[i]=new createjs.Text("??","10px "+FONT1, "#000");
    		aWinBoxWinAmountText[i].x = iWinX + 30;
    		aWinBoxWinAmountText[i].y = iWinY + 40;
    		aWinBoxWinAmountText[i].textAlign = "center";
    		_oContainer.addChild(aWinBoxWinAmountText[i]);
    		aWinBoxWinAmountText[i].visible = false;
    		
            _aEnlights["oEnlight_"+i] = oBmp;
            _aEnlights["oWinBox_oEnlight_"+i] = oWinBox;	//Preet Logic:  oWinBox_oEnlight_ code for Win box   
        }
        

        
        
        /*********************OTHER ENLIGHTS*****************/
        
        /*
        oBmp = new CEnlight(842,159,s_oSpriteLibrary.getSprite('enlight_number'),_oContainer);
        _aEnlights["oEnlight_col1"] = oBmp;
        
        oBmp = new CEnlight(842,85,s_oSpriteLibrary.getSprite('enlight_number'),_oContainer);
        _aEnlights["oEnlight_col2"] = oBmp;
        
        oBmp = new CEnlight(842,11,s_oSpriteLibrary.getSprite('enlight_number'),_oContainer);
        _aEnlights["oEnlight_col3"] = oBmp;
        
        
        oBmp = new CEnlight(98,234,s_oSpriteLibrary.getSprite('enlight_horizontal'),_oContainer);
        _aEnlights["oEnlight_first12"] = oBmp;
        
        oBmp = new CEnlight(347,234,s_oSpriteLibrary.getSprite('enlight_horizontal'),_oContainer);
        _aEnlights["oEnlight_second12"] = oBmp;
        
        oBmp = new CEnlight(595,234,s_oSpriteLibrary.getSprite('enlight_horizontal'),_oContainer);
        _aEnlights["oEnlight_third12"] = oBmp;
        
        oBmp = new CEnlight(98,345,s_oSpriteLibrary.getSprite('enlight_horizontal_half'),_oContainer);
        _aEnlights["oEnlight_first18"] = oBmp;
        
        oBmp = new CEnlight(220,345,s_oSpriteLibrary.getSprite('enlight_horizontal_half'),_oContainer);
        _aEnlights["oEnlight_even"] = oBmp;
        
        oBmp = new CEnlight(347,348,s_oSpriteLibrary.getSprite('enlight_color'),_oContainer);
        _aEnlights["oEnlight_black"] = oBmp;
        
        oBmp = new CEnlight(470,348,s_oSpriteLibrary.getSprite('enlight_color'),_oContainer);
        _aEnlights["oEnlight_red"] = oBmp;
        
        oBmp = new CEnlight(595,345,s_oSpriteLibrary.getSprite('enlight_horizontal_half'),_oContainer);
        _aEnlights["oEnlight_odd"] = oBmp;
        
        oBmp = new CEnlight(717,345,s_oSpriteLibrary.getSprite('enlight_horizontal_half'),_oContainer);
        _aEnlights["oEnlight_second18"] = oBmp;
        */
    };
	
    this.unload = function(){
            for(var i=0;i<_oContainer.getNumChildren();i++){
                    var oBut = _oContainer.getChildAt(i);
                    if(oBut instanceof CBetTableButton){
                            oBut.unload();
                    }
            }
    };
    
    this.addEventListener = function( iEvent,cbCompleted, cbOwner ){
        _aCbCompleted[iEvent]=cbCompleted;
        _aCbOwner[iEvent] = cbOwner; 
    };
    
    this._onBetPress = function(oParams){
        var aBets=oParams.numbers;
        if (aBets !== null) {
            if(_aCbCompleted[ON_SHOW_BET_ON_TABLE]){
                _aCbCompleted[ON_SHOW_BET_ON_TABLE].call(_aCbOwner[ON_SHOW_BET_ON_TABLE],oParams,false);
            }
        }
    };
    
    this._onBetNumberOver = function(oParams){
        
        var aBets=oParams.numbers;
        if(aBets !== null){
            if(_aCbCompleted[ON_SHOW_ENLIGHT]){
                _aCbCompleted[ON_SHOW_ENLIGHT].call(_aCbOwner[ON_SHOW_ENLIGHT],oParams);
            }
        }
    };
    
    this._onBetNumberOut = function(oParams){
        var aBets=oParams.numbers;
        if(aBets !== null){
            if(_aCbCompleted[ON_HIDE_ENLIGHT]){
                _aCbCompleted[ON_HIDE_ENLIGHT].call(_aCbOwner[ON_HIDE_ENLIGHT],oParams);
            }
        }
    };
    
    this.enlight = function(szEnlight){
    	_aEnlights[szEnlight].show();
        
        
        //Preet Logic: added to show the number on which mouse is over and the betting amout 
        var betNum = new Array();		//szEnlight value is "oEnlight_0","oEnlight_1" etc.. to know the index splitted it betNum = {"oEnlight_","0"}
        betNum= szEnlight.split("_");
        
        aEnlightBetAmountText[betNum[1]].text = _aBetAmount[betNum[1]].toFixed(0);
		aEnlightBetAmountText[betNum[1]].visible = true;
		
		//alert(_aBetAmount[betNum[1]].toFixed(0));
		
		var tmpBetNum = betNum[1];		//all numbers are double digit number from 00-99 but till 9 it was showing 1 digit so added 0 as prefix for numbers from 0-9
        if(betNum[1].length === 1){
        	tmpBetNum = "0" + betNum[1];
        }
        if(betNum[1] < 100) {
        	aEnlightSelectedNumText[betNum[1]].text = tmpBetNum;
            aEnlightSelectedNumText[betNum[1]].visible = true;
        } else {
        	tmpBetNum = betNum[1].substr(-1);
        }
        
        if(_aBetAmount[betNum[1]].toFixed(0) > 0) { 	//WinBox visible only for those numbers which are betted. for 0 bet amount winbox is hidden
			_aEnlights["oWinBox_" + szEnlight].show();
			aWinBoxSelectedNumText[betNum[1]].text ="No: " + tmpBetNum; //Dont forget to change the same thing in Interface->setCurBet
			aWinBoxSelectedNumText[betNum[1]].visible = true;
			aWinBoxBetAmountText[betNum[1]].text ="Play: " + _aBetAmount[betNum[1]].toFixed(0);
			aWinBoxBetAmountText[betNum[1]].visible = true;
			if(betNum[1] < 100) {
				aWinBoxWinAmountText[betNum[1]].text ="WIN: " + _aBetAmount[betNum[1]].toFixed(0) * NUM_MULTIPLE; //Dont forget to change the same thing in Interface->setCurBet
			} else {
				aWinBoxWinAmountText[betNum[1]].text ="WIN: " + _aBetAmount[betNum[1]].toFixed(0) * 9; //Dont forget to change the same thing in Interface->setCurBet
			}
			
			aWinBoxWinAmountText[betNum[1]].visible = true;
		}
        
    };
    
    this.enlightOff = function(szEnlight){
    	_aEnlights[szEnlight].hide();
    	var betNum = new Array();		  
        betNum= szEnlight.split("_");
        
    	aEnlightBetAmountText[betNum[1]].visible = false;
    	if(betNum[1] < 100) {
    		aEnlightSelectedNumText[betNum[1]].visible = false;
    	}
    	
        if(_aBetAmount[betNum[1]] > 0) {
        	_aEnlights[szEnlight].show();
        	if(betNum[1] < 100) {
        		aEnlightSelectedNumText[betNum[1]].visible = true;
        	}
            aEnlightBetAmountText[betNum[1]].visible = true;
        }
        
        _aEnlights["oWinBox_" + szEnlight].hide();
        aWinBoxSelectedNumText[betNum[1]].visible = false;
        aWinBoxBetAmountText[betNum[1]].visible = false;
        aWinBoxWinAmountText[betNum[1]].visible = false;
    };
    
  //Preet Logic: added to show the number on which mouse is over and the betting amout
    this.enlightOffAll = function(){
    	for(var i = 0; i < 120; i++) {
    		_aEnlights["oEnlight_"+i].hide();
    		aEnlightBetAmountText[i].visible = false;
    		if(aEnlightSelectedNumText[i] != null) {
				aEnlightSelectedNumText[i].visible = false;
			}
    	}
    };
	
    
    this.getEnlightX = function(iNumberExtracted){
        return _aEnlights["oEnlight_"+iNumberExtracted].getX();
    };
    
    this.getEnlightY = function(iNumberExtracted){
        return _aEnlights["oEnlight_"+iNumberExtracted].getY();
    };
    
    this.getContainer = function(){
        return _oContainer;
    };
    
    this.getX = function(){
        return _oContainer.x;
    };
    
    this.getY = function(){
        return _oContainer.x;
    };
    
    this._init();
}

 
var aEnlightBetAmountText; 
var aWinBoxWinAmountText;
var aWinBoxBetAmountText;