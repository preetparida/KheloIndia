function CFinalBetPanel(iX,iY){
    var _aNumberFinals;
    var _oContainer;
    
    this._init = function(iX,iY){
        _aNumberFinals=new Array();
        _aNumberFinals[0]=new Array(0,1,2,3,4,5,6,7,8,9);
        _aNumberFinals[1]=new Array(10,11,12,13,14,15,16,17,18,19);
        _aNumberFinals[2]=new Array(20,21,22,23,24,25,26,27,28,29);
        _aNumberFinals[3]=new Array(30,31,32,33,34,35,36,37,38,39);
        _aNumberFinals[4]=new Array(40,41,42,43,44,45,46,47,48,49);
        _aNumberFinals[5]=new Array(50,51,52,53,54,55,56,57,58,59);
        _aNumberFinals[6]=new Array(60,61,62,63,64,65,66,67,68,69);
        _aNumberFinals[7]=new Array(70,71,72,73,74,75,76,77,78,79);
        _aNumberFinals[8]=new Array(80,81,82,83,84,85,86,87,88,89);
        _aNumberFinals[9]=new Array(90,91,92,93,94,95,96,97,98,99);
                        
        _oContainer = new createjs.Container();
        _oContainer.x = iX;
        _oContainer.y = iY;
        s_oStage.addChild(_oContainer);
        
        var oSprite = s_oSpriteLibrary.getSprite('final_bet_bg');
        var iXOffset = oSprite.width/2;
        var iYOffset = oSprite.height/2;
        for(var i=0;i<10;i++){
            var oBut = new CTextButton(iXOffset,iYOffset,oSprite,""+i,FONT1,"#fff",14,false);
            oBut.addEventListenerWithParams(ON_MOUSE_UP, this._onFinalBetPressed, this,{index:i});
            _oContainer.addChild(oBut.getSprite());
            
            if(i===4){
                iXOffset = oSprite.width/2;
                iYOffset +=oSprite.height;
            }else{
                iXOffset += oSprite.width + 2;
            }
            
        }
        
        _oContainer.visible = false;
    };
	
    this.unload = function(){
        for(var i=0;i<_oContainer.getNumChildren();i++){
                if(oBut instanceof CTextButton){
                        var oBut = _oContainer.getChildAt(i);
                        oBut.unload();
                }
        }
    };
    
    this.show = function(){
        _oContainer.visible = true;
    };
    
    this.hide = function(){
        _oContainer.visible = false;
    };
   
    this._onFinalBetPressed = function(oParams){
        var iIndex=oParams.index;
        var iBetWin=_aNumberFinals[iIndex].length === 10?9:9;
        var iBetMultiplier=_aNumberFinals[iIndex].length === 10?10:10;

        s_oGame._onShowBetOnTable({button:"oBetFinalsBet",numbers:_aNumberFinals[iIndex],bet_mult:iBetMultiplier,
                                                                bet_win:iBetWin,num_fiches:_aNumberFinals[iIndex].length},false);

        this.hide();
    };
  
    
    this.isVisible = function(){
        return _oContainer.visible;
    };
    
    this._init(iX,iY);
}